import turtle
my_turtle=turtle.Turtle()
my_turtle.shape("turtle")
for count in range(4):
  my_turtle.forward(100)
  my_turtle.right(90)
turtle.done()
