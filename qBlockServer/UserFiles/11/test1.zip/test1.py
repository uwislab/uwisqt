for count in range(10):
  print('你好')
