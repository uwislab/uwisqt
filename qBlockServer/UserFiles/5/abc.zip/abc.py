if True:
  for count in range(10):
    print('abc')
